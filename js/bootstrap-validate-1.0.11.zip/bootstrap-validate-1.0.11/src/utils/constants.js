module.exports = {
  CLASS_ERROR: "has-error",
  ELEMENT_HELP_BLOCK: "span",
  CLASS_HELP_BLOCK: "help-block",
  SEPARATOR_RULE: "|",
  SEPARATOR_OPTION: ":",
  CLASS_LABEL: "control-label"
};

export default module.exports;
