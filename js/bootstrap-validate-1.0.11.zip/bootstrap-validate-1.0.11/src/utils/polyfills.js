// Polyfill for classList. methods for older IEs
import "classlist.js";
// Polyfill for element.closest and element.matches.
import "element-closest";
